/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import java.sql.*;
/**
 *
 * @author RIA KUSMARA
 */
public class Koneksi {
    public static Connection koneksi = null;
    public static Connection koneksiDatabase() {
        try{
            //setting driver mySQL
            Class.forName("com.mysql.jdbc.Driver");
            //buat connection
            koneksi = DriverManager.getConnection("jdbc:mysql:///moencak","root","");
        }catch (ClassNotFoundException | SQLException e) {
            System.out.println("Connection Error : " + e.getMessage());
        }
        return koneksi;
    }
}
