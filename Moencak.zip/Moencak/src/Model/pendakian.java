/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import java.sql.*;
/**
 *
 * @author RIA KUSMARA
 */
public class pendakian {
    private static String query;
    private static ResultSet rs;
    private static Statement stmt;
    private static ResultSet rs_c;
    private static Statement stmt_c;
    private static int jumBaris;
    
    //get list provinsi (untuk combobox)
    public static String[] getListProvinsi(){
        String data[]=null;
        Connection connect = Koneksi.koneksiDatabase();
        try{
            stmt = connect.createStatement();
            query = "SELECT nama_provinsi "
                    + "FROM provinsi ";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta= rs.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data = new String[1000];
            int r = 0;
            while(rs.next()){
                String nama = rs.getString(1);
                String list = nama;
                data[r]= list;
                r++;
            }
            int jmlBaris = r;
            String [] tmparray = data;
            data = new String[jmlBaris];
            for (r = 0; r<jmlBaris; r++){
                data[r] = tmparray[r];
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return data;
    }
    
    public static String[] getListGunungJB(){
        String data[]=null;
        Connection connect = Koneksi.koneksiDatabase();
        try{
            stmt = connect.createStatement();
            query = "SELECT nama_gunung "
                    + "FROM gunung WHERE id_provinsi = 1 ";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta= rs.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data = new String[1000];
            int r = 0;
            while(rs.next()){
                String nama = rs.getString(1);
                String list = nama;
                data[r]= list;
                r++;
            }
            int jmlBaris = r;
            String [] tmparray = data;
            data = new String[jmlBaris];
            for (r = 0; r<jmlBaris; r++){
                data[r] = tmparray[r];
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return data;
    }
    public static String[] getListGunungJTg(){
        String data[]=null;
        Connection connect = Koneksi.koneksiDatabase();
        try{
            stmt = connect.createStatement();
            query = "SELECT nama_gunung "
                    + "FROM gunung WHERE id_provinsi = 2 ";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta= rs.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data = new String[1000];
            int r = 0;
            while(rs.next()){
                String nama = rs.getString(1);
                String list = nama;
                data[r]= list;
                r++;
            }
            int jmlBaris = r;
            String [] tmparray = data;
            data = new String[jmlBaris];
            for (r = 0; r<jmlBaris; r++){
                data[r] = tmparray[r];
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return data;
    }
    public static String[] getListGunungJT(){
        String data[]=null;
        Connection connect = Koneksi.koneksiDatabase();
        try{
            stmt = connect.createStatement();
            query = "SELECT nama_gunung "
                    + "FROM gunung WHERE id_provinsi = 3 ";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta= rs.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data = new String[1000];
            int r = 0;
            while(rs.next()){
                String nama = rs.getString(1);
                String list = nama;
                data[r]= list;
                r++;
            }
            int jmlBaris = r;
            String [] tmparray = data;
            data = new String[jmlBaris];
            for (r = 0; r<jmlBaris; r++){
                data[r] = tmparray[r];
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return data;
    }
    
    
}
