/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import java.sql.*;

/**
 *
 * @author RIA KUSMARA
 */
public class dataPendaki {
    private static String query;
    private static ResultSet rs;
    private static Statement stmt;
    private static ResultSet rs_c;
    private static Statement stmt_c;
    private static int jumBaris;
    
    public static String [][] getDataPendaki(){
        Connection connect = Koneksi.koneksiDatabase();
        String data[][] = null;
        try{
            stmt = connect.createStatement();
            //ambil data
            query = "SELECT nama_pendaki, nik_pendaki, jk_pendaki, alamat_pendaki, tlp_pendaki, email_pendaki "
                    +"FROM data_pendaki "
                    +"ORDER BY id_pendaki";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data = new String[1000][jmlKolom];
            int r = 0;
            while(rs.next()){
                for(int c = 0; c<jmlKolom; c++){
                data[r][c] = rs.getString(c+1);
            }
                r++;
            }
            int jmlBaris = r;
            String [][]tmparray = data;
            data = new String[jmlBaris][jmlKolom];
            for (r = 0; r<jmlBaris; r++){
                for(int c = 0; c<jmlKolom ; c++){
                data[r][c] = tmparray[r][c];
                }
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return data;
    }
    
    public static int TambahDataPendaki(String nama, String nik, String jkPendaki, String alamat, String tlpPendaki, String email){
        jumBaris = 0;
        Connection connect = Koneksi.koneksiDatabase();
        try{
            stmt = connect.createStatement();
            query = "INSERT INTO data_pendaki "
                    +"(nama_pendaki, nik_pendaki, jk_pendaki, alamat_pendaki, tlp_pendaki, email_pendaki ) "
                    +"VALUES ('"+nama+"','"+nik+"','"+jkPendaki+"','"+alamat+"','"+tlpPendaki+"','"+email+"')";
            stmt.executeUpdate(query);
            stmt_c = connect.createStatement();
            rs_c = stmt_c.executeQuery("SELECT COUNT(*) FROM `data_pendaki`");
            while (rs_c.next()){
                jumBaris = rs_c.getInt(1);
            }
            stmt.close();
            stmt_c.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return jumBaris;
    }
    
    //cari kategori
    public static String [][] CariDataPendaki(String data_pendaki){
        Connection connect = Koneksi.koneksiDatabase();
        String data [][] = null;
        try{
            stmt = connect.createStatement();
            query = "SELECT nama_pendaki, nik_pendaki, jk_pendaki, alamat_pendaki, tlp_pendaki, email_pendaki "
                    +"FROM data_pendaki WHERE nama_pendaki "
                    +"LIKE '%"+data_pendaki+"%' ORDER BY nama_pendaki";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data = new String[1000][jmlKolom];
            int r = 0;
            while(rs.next()){
                for(int c = 0; c<jmlKolom; c++){
                data[r][c] = rs.getString(c+1);
            }
                r++;
            }
            int jmlBaris = r;
            String [][]tmparray = data;
            data = new String[jmlBaris][jmlKolom];
            for (r = 0; r<jmlBaris; r++){
                for(int c = 0; c<jmlKolom ; c++){
                data[r][c] = tmparray[r][c];
                }
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return data;
    }
    
    public static void editDataPendaki(String idPendaki, String nama, String nik, String jkPendaki, String alamat, String tlpPendaki, String email){
        Connection connect = Koneksi.koneksiDatabase();
        try{
            stmt = connect.createStatement();
            query = "UPDATE data_pendaki SET `nama_pendaki`='"+nama+"', "
                    +"`nik_pendaki`= '"+nik+"', "
                    +"`jk_pendaki`= '"+jkPendaki+"', "
                    +"`alamat_pendaki`= '"+alamat+"', "
                    +"`tlp_pendaki`= '"+tlpPendaki+"', "
                    +"`email_pendaki`= '"+email+"' "
                    +"WHERE `kode_buku`= '"+idPendaki+"'";
            stmt.executeUpdate(query);
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
}
}
