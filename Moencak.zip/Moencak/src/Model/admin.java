/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import java.sql.*;

/**
 *
 * @author RIA KUSMARA
 */
public class admin {
    private static String query;
    private static ResultSet rs;
    private static Statement stmt;
    private static int IDAdmin;
    private static ResultSet result;
    
    public static void setIDAdmin(int id_admin){
        admin.IDAdmin = id_admin;
    }
    
    public static int getIDAdmin(){
        return IDAdmin;
    }
    
    //get username password
    public static int CekAdmin(String username, String password){
        Connection connect = Koneksi.koneksiDatabase();
        int data = 0;
        try{
            stmt = connect.createStatement();
            query = "SELECT COUNT(id_admin) FROM data_admin WHERE username = '"+username+"'"
                    + "and password='"+password+"'";
            rs = stmt.executeQuery(query);
            while (rs.next()){
                data = rs.getInt(1);
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ ex.getMessage());
        }
        return data;
    }
    
     public static int GetIdAdmin(String username, String password){
        Connection connect = Koneksi.koneksiDatabase();
        int data = 0;
        try{
            stmt = connect.createStatement();
            query = "SELECT id_admin FROM data_admin WHERE username= '"+username+"'"
                    + "and password='"+password+"'";
            rs = stmt.executeQuery(query);
            while (rs.next()){
                data = rs.getInt(1);
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error: "+ex.getMessage());
        }
        return data;
    }
     
      public static String [][] getProfil(int idAdmin) {
        Connection conn = Koneksi.koneksiDatabase();
        String [][] data = null;
        try {
            stmt = conn.createStatement();
            query = "SELECT * FROM data_admin WHERE id_admin = '"+ idAdmin +"'";
            result = stmt.executeQuery(query);
            ResultSetMetaData meta = result.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data = new String [1000][jmlKolom];
            int r = 0;
            while (result.next()) {
                for(int c = 0; c < jmlKolom; c++) {
                    data[r][c] = result.getString(c+1);
                }
                r++;
            }
            int jmlBaris = r;
            String [][] tmpArray = data;
            data = new String[jmlBaris][jmlKolom];
            for(r = 0; r < jmlBaris; r++) {
                for(int c = 0; c < jmlKolom; c++) {
                    data[r][c] = tmpArray[r][c];
                }
            }
            stmt.close();
            conn.close();
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
        return data;
    }
}
